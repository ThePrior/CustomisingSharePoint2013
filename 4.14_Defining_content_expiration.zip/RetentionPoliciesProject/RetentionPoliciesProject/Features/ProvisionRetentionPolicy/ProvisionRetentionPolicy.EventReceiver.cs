using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.Office.RecordsManagement.InformationPolicy;
using Microsoft.SharePoint.Workflow;
using System.Globalization;

namespace RetentionPoliciesProject.Features.ProvisionRetentionPolicy
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("96c8ef1f-f316-4d60-8ef7-b5d4fc1d45dc")]
    public class ProvisionRetentionPolicyEventReceiver : SPFeatureReceiver
    {
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            SPSite site = properties.Feature.Parent as SPSite;

            // enabling policy feature pre-requisite
            // Features/LocationBasedPolicy
            if (site.Features[new Guid("063C26FA-3CCC-4180-8A84-B6F98E991DF3")]== null)
            {
                site.Features.Add(new Guid("063C26FA-3CCC-4180-8A84-B6F98E991DF3"));
            }

            // enabling out-of-the-box workflows
            // Features/Workflows
            if (site.Features[new Guid("0AF5989A-3AEA-4519-8AB0-85D91ABE39FF")] == null)
            {
                site.Features.Add(new Guid("0AF5989A-3AEA-4519-8AB0-85D91ABE39FF"));
            }

            // iterating through all of the libraries on the site and its sub sites
            foreach (SPWeb web in site.AllWebs)
            {
                foreach (SPList list in web.Lists)
                {
                    if (list.BaseTemplate == SPListTemplateType.DocumentLibrary)
                    {
                        ProvisionApprovalWorkflow(web, list);
                        CreateExpirationPolicy(list);
                    }
                }
            }
        }

        private static void ProvisionApprovalWorkflow(SPWeb web, SPList list)
        {
            // get all workflow templates on site
            SPWorkflowTemplateCollection workflowTemplates = web.WorkflowTemplates;

            // get workflow template for disposition approval
            SPWorkflowTemplate workflowTemplate =
                workflowTemplates.GetTemplateByName("Disposition Approval",
                CultureInfo.InvariantCulture);

            // create required lists for workflow tasks and workflow history
            if (web.Lists["Workflow Tasks"]==null)
            {
                web.Lists.Add("Workflow Tasks", string.Empty, SPListTemplateType.Tasks);
            }
            if (web.Lists["Workflow History"] == null)
            {
                web.Lists.Add("Workflow History", string.Empty, SPListTemplateType.WorkflowHistory);
            }

            // check if workflo already exists on this list
            SPWorkflowAssociation workflowAssociation =
                list.WorkflowAssociations.GetAssociationByName("DispositionReminder", CultureInfo.InvariantCulture);

            if (workflowAssociation != null)
            {
                // add a disposition workflow to a list
                workflowAssociation = SPWorkflowAssociation.CreateListAssociation(workflowTemplate,
                    "DispositionReminder", web.Lists["Workflow Tasks"], web.Lists["Workflow History"]);
                list.WorkflowAssociations.Add(workflowAssociation);
            }
        }

        private static void CreateExpirationPolicy(SPList list)
        {
            // get policies for list
            ListPolicySettings listPolicy = new ListPolicySettings(list);

            // ensure usage of policy is turned on
            if (!listPolicy.ListHasPolicy)
            {
                listPolicy.UseListPolicy = true;
                listPolicy.Update();
            }

            // policy will be applied on a "Document" content type
            SPContentType contentType = list.ContentTypes["Document"];

            if (contentType != null)
            {
                // creating a new policy on the content type
                Policy.CreatePolicy(contentType, null);
                Policy newPolicy = Policy.GetPolicy(contentType);

                // adding policy rule from the resource file
                newPolicy.Items.Add("Microsoft.Office.RecordsManagement.PolicyFeatures.Expiration",
                    string.Format(Resource1.PolicyRule,
                    list.WorkflowAssociations.GetAssociationByName("DispositionReminder", CultureInfo.InvariantCulture).Id));

                // saving changes
                newPolicy.Update();
                list.Update();
            }
        }


        // Uncomment the method below to handle the event raised before a feature is deactivated.

        //public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised after a feature has been installed.

        //public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is uninstalled.

        //public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        //{
        //}

        // Uncomment the method below to handle the event raised when a feature is upgrading.

        //public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, System.Collections.Generic.IDictionary<string, string> parameters)
        //{
        //}
    }
}
