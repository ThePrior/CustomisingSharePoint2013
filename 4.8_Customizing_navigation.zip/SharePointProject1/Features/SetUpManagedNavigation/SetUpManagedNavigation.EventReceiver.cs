using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Publishing;
using Microsoft.SharePoint.Publishing.Navigation;
using Microsoft.SharePoint.Taxonomy;


namespace SharePointProject1.Features.SetUpManagedNavigation
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("bf4c3fc6-3714-4d9a-8c0a-dd3d494b0c9a")]
    public class SetUpManagedNavigationEventReceiver : SPFeatureReceiver
    {
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            using (SPWeb web = properties.Feature.Parent as SPWeb)
            {
                TermStore store = ProvisionTermsStructure(web);

                PublishingWeb pw = Microsoft.SharePoint.Publishing.PublishingWeb.GetPublishingWeb(web);
                WebNavigationSettings navSettings = new WebNavigationSettings(web);

                navSettings.GlobalNavigation.Source = StandardNavigationSource.TaxonomyProvider;
                navSettings.GlobalNavigation.TermStoreId = store.Id;
                TermSetCollection termSetCol = store.GetTermSets("NavTermSet", 1033);
                if (termSetCol.Count > 0)
                {
                    navSettings.GlobalNavigation.TermSetId = termSetCol[0].Id;
                }
                navSettings.AddNewPagesToNavigation = true;
                navSettings.CreateFriendlyUrlsForNewPages = true;
                navSettings.Update();
                pw.Update();
            }
        }



        private TermStore ProvisionTermsStructure(SPWeb web)
        {
            TaxonomySession session = new TaxonomySession(web.Site);
            TermStore store = session.TermStores["ManagedMetadata"];
            TermSetCollection collection = store.GetTermSets("NavTermSet", 1033);
            if (collection != null && collection.Count == 0)
            {
                Group group = store.CreateGroup("PublishingNav");
                TermSet termSet = group.CreateTermSet("NavTermSet");
                Term term1 = termSet.CreateTerm("Nav Item 1", 1033);
                term1.CreateTerm("Sub Term 1", 1033);
                termSet.CreateTerm("Nav Item 2", 1033);
                store.CommitAll();
            }
            return store;
        }


        // Uncomment the method below to handle the event raised before a feature is deactivated.

        //public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised after a feature has been installed.

        //public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is uninstalled.

        //public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        //{
        //}

        // Uncomment the method below to handle the event raised when a feature is upgrading.

        //public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, System.Collections.Generic.IDictionary<string, string> parameters)
        //{
        //}
    }
}
