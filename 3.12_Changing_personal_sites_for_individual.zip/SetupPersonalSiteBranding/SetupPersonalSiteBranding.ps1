﻿function DeployFeatures($featureList, $url) {
	foreach ($feature in $featureList) {
		if ($feature.Name -and $feature.Id) {
			$featurePath = $feature.Name
			
			Write-Host "Adding Feature: $featurePath" 
			$SPFeature = Get-SPFeature | Where-Object { $_.Id -eq $feature.Id }

			if(!$SPFeature.Id) {
				$status = Install-SPFeature $featurePath -force
			}

			$status = Enable-SPFeature -Identity $feature.Id -Url $url -force
		}
		else {
			Write-Host "Failed to enable feature, ensure you have specified Id and Name." -foregroundcolor Red
		}
	}
}

function SetUpBranding($siteCollections, [string]$rootUrl)
{
	if($siteCollections -ne $null)
	{
		Write-Host
		"Setting up Personal Site Branding"

		$siteCollectionList = $siteCollections.Item(0).SelectNodes("SiteCollection")
		
		$webApp = Get-SPWebApplication $rootUrl

		foreach($SiteCollection in $siteCollectionList) {
			if ($SiteCollection.Url -eq "/") {
				$SiteUrl = ($WebAppUrl + $SiteCollection.Url)
			} else {
				if (($SiteCollection.ManagedPath -eq $null) -or ($SiteCollection.ManagedPath.Trim() -eq "") ) {
					$SiteUrl = ($WebAppUrl + "/Sites" + $SiteCollection.Url)
				} else {
					$SiteUrl = ($WebAppUrl + $SiteCollection.ManagedPath + $SiteCollection.Url)
				}
			}

			$SiteUrl = $SiteUrl -replace "/$", ""

			$NewSite = Get-SPSite | Where-Object {$_.Url -eq  $SiteUrl}
			$RootWeb = $NewSite.RootWeb

			Write-Host "Provisioning master page feature"
			DeployFeatures $SiteCollection.SelectNodes("Features/Feature") $RootWeb.Url

			Write-Host "URL:" $RootWeb.Url -foregroundcolor Green
		}
	}
}

function InitApplication()
{
	Write-Host
	"Initializing ..."

	$snapin = Get-PSSnapin | Where-Object {$_.Name -eq 'Microsoft.SharePoint.Powershell'}
	if ($snapin -eq $null) {
		Write-Host "Loading SharePoint Powershell Snapin"
		Add-PSSnapin "Microsoft.SharePoint.Powershell"
	}
}

try 
{
	[xml]$ConfigFile = Get-Content "Config.xml"
}
catch
{
	Write-Host "Failed to load the configuration file (Config.xml), ensure it's in the same directory as the script"

	return
}

$WebAppUrl = $ConfigFile.Setup.WebAppUrl -replace "/$", ""

# initialize application, load relevant snap-ins and assemblies
InitApplication

# set personal site branding
SetUpBranding $ConfigFile.SelectNodes("/Setup/SiteCollections") $WebAppUrl