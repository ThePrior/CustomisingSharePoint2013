﻿namespace SharePointProject1.ControlTemplates.SharePointProject1
{
    public partial class CustomSuiteBar
    {
    }
}
