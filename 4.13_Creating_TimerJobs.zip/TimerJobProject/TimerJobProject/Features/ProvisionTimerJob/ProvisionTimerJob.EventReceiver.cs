using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using System.Diagnostics;


namespace TimerJobProject.Features.ProvisionTimerJob
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("768597b6-f878-4f2d-8c27-374ece1d732b")]
    public class ProvisionTimerJobEventReceiver : SPFeatureReceiver
    {
        // Uncomment the method below to handle the event raised after a feature has been activated.

        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            SPWebApplication webApplication = (SPWebApplication)properties.Feature.Parent;
            SPJobDefinition jobDefinition = webApplication.JobDefinitions["My Timer Job"];
            if (jobDefinition != null)
            {
                jobDefinition.Delete();
            }
            try
            {
                MyJobDefinition myJobDefinition = new MyJobDefinition("MyTimerJobID", webApplication);
                SPMinuteSchedule minuteSchedule = new SPMinuteSchedule();
                minuteSchedule.BeginSecond = 1;
                minuteSchedule.EndSecond = 59;
                minuteSchedule.Interval = 1;
                myJobDefinition.Schedule = minuteSchedule;
                myJobDefinition.Update();
            }
            catch (Exception ex)
            {
                Debug.Write("Exception in Feature Activated occurred: " + ex.Message);
            }
        }


        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            SPWebApplication webApplication =
        (SPWebApplication)properties.Feature.Parent;
            SPJobDefinition jobDefinition =
            webApplication.JobDefinitions["My Timer Job"];
            if (jobDefinition != null)
            {
                jobDefinition.Delete();
            }
        }


        // Uncomment the method below to handle the event raised after a feature has been installed.

        //public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is uninstalled.

        //public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        //{
        //}

        // Uncomment the method below to handle the event raised when a feature is upgrading.

        //public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, System.Collections.Generic.IDictionary<string, string> parameters)
        //{
        //}
    }
}