using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using Microsoft.SharePoint;

namespace CustomLook.Features.ProvisionCustomLook
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("68b229fc-fa5c-48ed-b185-b3302bec8416")]
    public class ProvisionCustomLookEventReceiver : SPFeatureReceiver
    {
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            SPWeb web = properties.Feature.Parent as SPWeb;
            SPList list = web.GetList("_catalogs/design");
            SPListItem item = list.AddItem();
            item["Title"] = "CustomLook";
            item[new Guid("{bfc6f32c-668c-43c4-a903-847cca2f9b3c}")] = "CustomLook";
            SPFieldUrlValue masterUrl = new SPFieldUrlValue();
            masterUrl.Url = "/_catalogs/masterpage/v15.master";
            masterUrl.Description = "/_catalogs/masterpage/v15.master";
            item["MasterPageUrl"] = masterUrl;

            SPFieldUrlValue themeUrl = new SPFieldUrlValue();
            themeUrl.Url = "/_catalogs/theme/15/CustomPalette.spcolor";
            themeUrl.Description = "/_catalogs/theme/15/CustomPalette.spcolor";
            item["ThemeUrl"] = themeUrl;

            SPFieldUrlValue imageUrl = new SPFieldUrlValue();
            imageUrl.Url = "/_layouts/15/images/CustomLook/ThemeImage.jpg";
            imageUrl.Description = "/_layouts/15/images/CustomLook/ThemeImage.jpg";
            item["ImageUrl"] = imageUrl;

            //item["FontSchemeUrl"] = "";
            //item["DisplayOrder"] = 100;
            item.Update();
        }


        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            SPWeb web = properties.Feature.Parent as SPWeb;
            SPList list = web.GetList("_catalogs/design");
        }


        // Uncomment the method below to handle the event raised after a feature has been installed.

        //public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is uninstalled.

        //public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        //{
        //}

        // Uncomment the method below to handle the event raised when a feature is upgrading.

        //public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, System.Collections.Generic.IDictionary<string, string> parameters)
        //{
        //}
    }
}
