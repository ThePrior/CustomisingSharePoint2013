﻿using Microsoft.Office.Server.UserProfiles;
using Microsoft.SharePoint;
using System;
using System.ComponentModel;
using System.Web.UI.WebControls.WebParts;


namespace SharePointProject1.ConfigureNavigationItem
{
    [ToolboxItemAttribute(false)]
    public partial class ConfigureNavigationItem : WebPart
    {
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]
        public ConfigureNavigationItem()
        {
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                string socialDataStatsSite = SPContext.Current.Site.Url;
                using (SPSite siteColl = new SPSite(socialDataStatsSite))
                {
                    SPServiceContext serviceContext = SPServiceContext.GetContext(siteColl);
                    UserProfile userProfile = ProfileLoader.GetProfileLoader().GetUserProfile();
                    if (userProfile["MyProperty"] != null
                        && userProfile["MyProperty"].Value != null)
                    {
                        string propValue = userProfile["MyProperty"].Value.ToString();
                        string[] navValues = propValue.Split(';');
                        NavTitle.Text = navValues[0];
                        NavUrl.Text = navValues[1];
                    }
                }
            }
        }

        protected void SaveNav_Click(object sender, EventArgs e)
        {
            string socialDataStatsSite = SPContext.Current.Site.Url;
            using (SPSite siteColl = new SPSite(socialDataStatsSite))
            {
                SPServiceContext serviceContext = SPServiceContext.GetContext(siteColl);
                UserProfile userProfile = ProfileLoader.GetProfileLoader().GetUserProfile();
                if (userProfile["MyProperty"] != null)
                {
                    userProfile["MyProperty"].Add(NavTitle.Text + ";" + NavUrl.Text);
                    userProfile.Commit();
                }
            }
        }
    }
}
