using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using Microsoft.SharePoint;

using Microsoft.Office.Server.UserProfiles;
using Microsoft.SharePoint.Taxonomy;
using Microsoft.SharePoint.WebControls;
using System.Web;
using Microsoft.SharePoint.Portal.WebControls;
using System.Collections.Generic;
using System.Diagnostics;

namespace ProvisionCustomProfileProperties.Features.ProvisionProfileProperties
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("32319381-125b-45f7-894b-ac8c219ed6ca")]
    public class ProvisionProfilePropertiesEventReceiver : SPFeatureReceiver
    {
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            SPSite siteColl = properties.Feature.Parent as SPSite;
            SPServiceContext serviceContext = SPServiceContext.GetContext(siteColl);
            UserProfileConfigManager upcm = new UserProfileConfigManager(serviceContext);
            ProfileSubtypeManager psm = ProfileSubtypeManager.Get(serviceContext);
            ProfileSubtype ps = psm.GetProfileSubtype(ProfileSubtypeManager.GetDefaultProfileName(ProfileType.User));
            ProfileSubtypePropertyManager pspm = ps.Properties;

            ProfilePropertyManager ppm = upcm.ProfilePropertyManager;
            CorePropertyManager cpm = ppm.GetCoreProperties();

            try
            {
                CoreProperty cp = cpm.Create(false); ;

                cp.Name = "MyProperty2";
                cp.DisplayName = "My Property 2";
                cp.Description = "My Property 2";
                cp.Type = "string";
                cp.IsMultivalued = true;
                cp.IsSearchable = true;
                cp.Length = 100;
                cpm.Add(cp);

                ProfileTypePropertyManager ptpm = ppm.GetProfileTypeProperties(ProfileType.User);
                ProfileTypeProperty ptp = ptpm.Create(cp);
                ptp.IsVisibleOnEditor = true;
                ptp.IsVisibleOnViewer = true;
                ptp.Commit();

                ProfileSubtypeProperty prop = pspm.Create(ptp);
                prop.DefaultPrivacy = Privacy.Public;
                prop.IsUserEditable = true;
                prop.PrivacyPolicy = PrivacyPolicy.OptIn;
                prop.UserOverridePrivacy = true;
                pspm.Add(prop);
            }
            catch (Exception exception)
            {
                Debug.Write(exception.Message);
            }
        }


        // Uncomment the method below to handle the event raised before a feature is deactivated.

        //public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised after a feature has been installed.

        //public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is uninstalled.

        //public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        //{
        //}

        // Uncomment the method below to handle the event raised when a feature is upgrading.

        //public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, System.Collections.Generic.IDictionary<string, string> parameters)
        //{
        //}
    }
}
