﻿using Microsoft.Office.Server.UserProfiles;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Portal.WebControls;
using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace SharePointProject1.ControlTemplates.SharePointProject1
{
    public partial class UserControl1 : MySuiteLinksUserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected override void Render(HtmlTextWriter writer)
        {
            string socialDataStatsSite = SPContext.Current.Site.Url;
            using (SPSite siteColl = new SPSite(socialDataStatsSite))
            {
                SPServiceContext serviceContext = SPServiceContext.GetContext(siteColl);
                UserProfile userProfile = ProfileLoader.GetProfileLoader().GetUserProfile();
                if (userProfile["MyProperty"] != null
                    && userProfile["MyProperty"].Value != null)
                {
                    string propValue = userProfile["MyProperty"].Value.ToString();
                    string[] navValues = propValue.Split(';');
                    writer.RenderBeginTag(HtmlTextWriterTag.Style);
                    writer.Write(".ms-core-suiteLinkList {display: inline-block;}");
                    writer.RenderEndTag();
                    writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-core-suiteLinkList");
                    writer.RenderBeginTag(HtmlTextWriterTag.Ul);
                    RenderSuiteLink(writer, navValues[1], navValues[0], navValues[0]+"Link", false);
                    writer.RenderEndTag();
                }
            }
            base.Render(writer);
        }
    }
}
