using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using Microsoft.SharePoint;

using Microsoft.Office.Server.UserProfiles;
using Microsoft.Office.Server;
using Microsoft.SharePoint.Taxonomy;
using System.Web;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Portal.WebControls;

namespace ProvisionUserProfiles.Features.ProvisionProfiles
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("26310695-66b3-4570-801f-1f45ee53d286")]
    public class ProvisionProfilesEventReceiver : SPFeatureReceiver
    {
        // Uncomment the method below to handle the event raised after a feature has been activated.

        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            SPSite siteColl = properties.Feature.Parent as SPSite;
            SPServiceContext serviceContext = SPServiceContext.GetContext(siteColl);
            UserProfileManager userProfileManager = new UserProfileManager(serviceContext);

            UserProfile existingProfile = userProfileManager.GetUserProfile("administrator");
            if (existingProfile != null)
            {
                userProfileManager.RemoveUserProfile(existingProfile.ID);
            }

            UserProfile newProfile = userProfileManager.CreateUserProfile("administrator", "administrator");
            newProfile[PropertyConstants.WorkPhone].Add("555-555-5555");
            newProfile[PropertyConstants.Department].Add("Marketing");
            newProfile[PropertyConstants.Title].Add("Chief");
            newProfile[PropertyConstants.DistinguishedName].Add("SPFarm");
            newProfile[PropertyConstants.Office].Add("Western Branch");
            newProfile.Commit();
        }


        // Uncomment the method below to handle the event raised before a feature is deactivated.

        //public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised after a feature has been installed.

        //public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is uninstalled.

        //public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        //{
        //}

        // Uncomment the method below to handle the event raised when a feature is upgrading.

        //public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, System.Collections.Generic.IDictionary<string, string> parameters)
        //{
        //}
    }
}
