function DeployFeatures($featureList, $url) {
	foreach ($feature in $featureList) {
		if ($feature.Name -and $feature.Id) {
			$featurePath = $feature.Name
			
			Write-Host "Adding Feature: $featurePath" 
			$SPFeature = Get-SPFeature | Where-Object { $_.Id -eq $feature.Id }

			if(!$SPFeature.Id) {
				$status = Install-SPFeature $featurePath -force
			}

			$status = Enable-SPFeature -Identity $feature.Id -Url $url -force
		}
		else {
			Write-Host "Failed to enable feature, ensure you have specified Id and Name." -foregroundcolor Red
		}
	}
}

function DeployWebFeatures($webList, $url, $rootUrl, [int]$level) {
	foreach($web in $webList) {
		$rootUrl = $rootUrl -replace "/$", ""

		$url = $url -replace "/$", ""
		$WebUrl = $url + $web.Url
		$WebUrl = $WebUrl -replace "/$", ""
		
		# Deploy features
		DeployFeatures $web.SelectNodes("Features/Feature") $WebUrl
		
		Write-Host "Title: " $NewWeb.Title -foregroundcolor Green
		Write-Host "URL: " $NewWeb.Url -foregroundcolor Green

		# Process child webs
		foreach($childWeb in $web.SelectNodes("Web")) {
			DeployWeb $childWeb $WebUrl $rootUrl ($level + 1)
		}
	}
}

function ProvisionSolutions($solutions, [string]$rootUrl)
{
	if($solutions -ne $null)	
	{	
		$solutionList = $solutions.Item(0).SelectNodes("Solution")
		
		Write-Host
		"Deploying Solutions"

		foreach ($solutionInstance in $solutionList) {
			$targetSolution = Get-SPSolution | Where-Object {$_.Name -eq $solutionInstance.InnerText}
				
			if ($targetSolution.Name.length -gt 0) {
				if ($targetSolution.Deployed -eq "True") {
					"{0,-36} {1,-36}" -f "Uninstalling existing solution", $solutionInstance.InnerText
					$WebAppInstallTarget = $solutionInstance.Attributes.Item(0).Value
						
					if ($WebAppInstallTarget -eq "True") {
						$status = Uninstall-SPSolution �Identity $targetSolution.Name �WebApplication $WebAppUrl -Confirm:$false
					}
					else {
						$status = Uninstall-SPSolution �Identity $targetSolution.Name -Confirm:$false
					}
				
					do {
						$targetSolution = Get-SPSolution | Where-Object {$_.Name -eq $solutionInstance.InnerText}
						Sleep -Milliseconds 100
					} while ($targetSolution.JobExists -eq "True")
				}
			
				"{0,-36} {1,-36}" -f "Removing existing solution", $solutionInstance.InnerText
				$status = Remove-SPSolution -Identity $solutionInstance.InnerText -Confirm:$false
			}

			"{0,-36} {1,-36}" -f "Adding solution", $solutionInstance.InnerText
			$status = Add-SPSolution -LiteralPath $solutionInstance.InnerText

			$sol = Get-SPSolution $solutionInstance.InnerText
			
			if($sol -ne $null) 
			{
				"{0,-36} {1,-36}" -f "Installing solution", $solutionInstance.InnerText
				$WebAppInstallTarget = $solutionInstance.Attributes.Item(0).Value
				
				if ($WebAppInstallTarget -eq "True") {
					$status = Install-SPSolution -Identity $solutionInstance.InnerText �WebApplication $WebAppUrl -GACDeployment -force
				}
				else {
					$status = Install-SPSolution -Identity $solutionInstance.InnerText -GACDeployment -force
				}

				do {
					$targetSolution = Get-SPSolution | Where-Object {$_.Name -eq $solutionInstance.InnerText}
					Sleep -Milliseconds 200
				} while ($targetSolution.Deployed -eq $false)
			}
			else
			{
				write-host ("{0,-36} {1,-36}" -f "Failed to Install", $solutionInstance.InnerText) -ForegroundColor Red
			}
			Write-Host "--- "
		}
	}
}

function DeploySiteCollectionFeatures($siteCollections, [string]$rootUrl)
{
	if($siteCollections -ne $null)
	{
		Write-Host
		"Deploying Site Collections"

		$siteCollectionList = $siteCollections.Item(0).SelectNodes("SiteCollection")
		
		$webApp = Get-SPWebApplication $rootUrl

		foreach($SiteCollection in $siteCollectionList) {
			if ($SiteCollection.Url -eq "/") {
				$SiteUrl = ($WebAppUrl + $SiteCollection.Url)
			} else {
				if (($SiteCollection.ManagedPath -eq $null) -or ($SiteCollection.ManagedPath.Trim() -eq "") ) {
					$SiteUrl = ($WebAppUrl + "/Sites" + $SiteCollection.Url)
				} else {
					$SiteUrl = ($WebAppUrl + $SiteCollection.ManagedPath + $SiteCollection.Url)
				}
			}

			$SiteUrl = $SiteUrl -replace "/$", ""

			DeployFeatures $SiteCollection.SelectNodes("Features/Feature") $RootWeb.Url
			
			Write-Host "Site collection created successfully"
			Write-Host "Title:" $RootWeb.Title -foregroundcolor Green
			Write-Host "URL:" $RootWeb.Url -foregroundcolor Green
			
			DeployWeb $SiteCollection.SelectNodes("Web") $SiteUrl $SiteUrl "0" 
		}
	}
}
function InitApplication()
{
	Write-Host
	"Initializing ..."

	$snapin = Get-PSSnapin | Where-Object {$_.Name -eq 'Microsoft.SharePoint.Powershell'}
	if ($snapin -eq $null) {
		Write-Host "Loading SharePoint Powershell Snapin"
		Add-PSSnapin "Microsoft.SharePoint.Powershell"
	}
}

try 
{
	[xml]$ConfigFile = Get-Content "Config.xml"
}
catch
{
	Write-Host "Failed to load the configuration file (Config.xml), ensure it's in the same directory as the script"

	return
}

$WebAppUrl = $ConfigFile.Setup.WebAppUrl -replace "/$", ""

# initialize the script
InitApplication

# install solutions
ProvisionSolutions $ConfigFile.SelectNodes("/Setup/Solutions") $WebAppUrl

# deploy site collection features
DeploySiteCollectionFeatures $SiteStructure.SelectNodes("/Setup/SiteCollections") $WebAppUrl