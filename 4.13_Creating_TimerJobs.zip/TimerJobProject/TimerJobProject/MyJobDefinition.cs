﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.SharePoint.Administration;
using System.Diagnostics;

namespace TimerJobProject
{
    public class MyJobDefinition : SPJobDefinition
    {
        public MyJobDefinition()
            : base()
        {
        }
        public MyJobDefinition(string jobName, SPWebApplication webApplication)
            : base(jobName, webApplication, null, SPJobLockType.Job)
        {
            this.Title = "My Timer Job Title";
        }
        public override void Execute(Guid targetInstanceId)
        {
            try
            {
                SPWebApplication webApplication = this.Parent as SPWebApplication;
                // TODO: your custom execution goes here
            }
            catch (Exception ex)
            {
                Debug.Write("Problem during service job execution:" + ex.Message);
            }
        }
    }
}