﻿function hideHeader() {
    $('#s4-titlerow').hide('slow');
    $('#show-header-link').show('fast');
    $('#hide-header-link').hide('fast');
    setCookie("CustomHeader", "hide", 100);
}

function showHeader() {
    $('#s4-titlerow').show('slow');
    $('#show-header-link').hide('fast');
    $('#hide-header-link').show('fast');
    deleteCookie("CustomHeader");
}

function setCookie(name, value, days) {
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        var expires = "; expires=" + date.toGMTString();
    }
    else var expires = "";
    document.cookie = name + "=" + value + expires + "; path=/";
}

function getCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
    }
    return null;
}

function deleteCookie(name) {
    setCookie(name, "", -1);
}


function setHeaderState() {
    if (getCookie("CustomHeader") != null) {
        $('#s4-titlerow').hide();
        $('#show-header-link').show();
        $('#hide-header-link').hide();
    }
}
