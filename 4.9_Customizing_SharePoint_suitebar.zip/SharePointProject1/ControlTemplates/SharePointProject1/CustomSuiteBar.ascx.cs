﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint.Portal.WebControls;
using Microsoft.SharePoint;

namespace SharePointProject1.ControlTemplates.SharePointProject1
{
    public partial class CustomSuiteBar : MySuiteLinksUserControl 
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected override void Render(HtmlTextWriter writer)
        {
            writer.RenderBeginTag(HtmlTextWriterTag.Style);
            writer.Write(".ms-core-suiteLinkList {display: inline-block;}");
            writer.RenderEndTag();
            writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-core-suiteLinkList");
            writer.RenderBeginTag(HtmlTextWriterTag.Ul);
            RenderSuiteLink(writer, "/", "Home", "HomeLink", false);
            writer.RenderEndTag();
            base.Render(writer);
        }

    }
}
